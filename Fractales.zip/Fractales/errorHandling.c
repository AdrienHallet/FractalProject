#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "handleArgument.h"

int handle_no_arguments(int argc){
	if(argc == 1){
		printf("Error : misusing the application\n");
		printf("   The correct usage would be :\n");
		printf("   ./main [-d] [--maxthreads n] inputFiles outputFile\n");
		return -1;
	}
	return 0; //I'm fine
}
