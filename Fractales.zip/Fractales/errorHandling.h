#ifndef _HANDLEARGUMENT_H
#define _HANDLEARGUMENT_H

int handle_no_arguments(int argc);
#endif
