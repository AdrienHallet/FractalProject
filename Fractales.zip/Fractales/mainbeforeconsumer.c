#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include "libfractal/fractal.h"
#include "errorHandling.h"

struct fractal *(*buffer)[];
int counter; //current buffered data
pthread_mutex_t buffer_access;
int maxthreads;
sem_t full, empty;

char *strsep(char **stringp, const char *delim){
	char *s;
	const char *spanp;
	int c, sc;
	char *tok;

	if ((s = *stringp) == NULL)
	    return (NULL);
	for (tok = s;;) {
	    c = *s++;
	    spanp = delim;
	    do {
		    if ((sc = *spanp++) == c) {
			    if (c == 0)
				    s = NULL;
			    else
				    s[-1] = 0;
			    *stringp = s;
			    return (tok);
		    }
	    } while (sc != 0);
	}
	/* NOTREACHED */
}

struct fractal *fractal_parse(char *line){
	const char *delim = " ";
	char **endptr;
	long value;
	char *name = strsep(&line, delim);
	printf("Will parse name = %s\n", name);
	int width = (int) strtol(strsep(&line, delim), endptr, 10);
	int height = (int) strtol(strsep(&line, delim), endptr, 10);
	double a = (double) strtol(strsep(&line, delim), endptr, 10);
	double b= (double) strtol(strsep(&line, delim), endptr, 10);
	struct fractal *newfractal = fractal_new(name, width, height, a, b);
	printf("Parsed fractal : %s\n", newfractal->name);
	return newfractal;
	
}

int insert_fractal(struct fractal *fractal){
	/* When the buffer is not full add the item
	and increment the counter*/
	if(counter < maxthreads) {
		(*buffer)[counter] = fractal;
		printf("Saved %s in %d\n", (*buffer)[counter]->name, counter-1);
		fflush(stdout);
		counter++;
		return 0;
	}
	else { /* Error the buffer is full */
		return -1;
	}
}

int *readFile(const char *filename){
	FILE *fp;
	char *line = NULL;
	size_t len = 0;
	ssize_t read;
	int *iteration;
	fp = fopen(filename, "r");
	if (fp == NULL)
	return -1;
	while ((read = getline(&line, &len, fp)) != -1) {
		if(read>1 && line[0]!='#'){ //ignore empty lines and comments
			sem_wait(&empty);
			struct fractal *myfrac = fractal_parse(line);
			iteration++;
			pthread_mutex_lock(&buffer_access);
			if(insert_fractal(myfrac)) {
				fprintf(stderr, " Producer report error condition\n");
			}
			/* release the mutex lock */
			pthread_mutex_unlock(&buffer_access);
			sem_post(&full);
		}
	}
	fclose(fp);
        free(line);
	pthread_exit(iteration);
}

/* Consumer Thread */
void *compute(void *param) {
   buffer_item item;

   while(TRUE) {
      /* sleep for a random period of time */
      int rNum = rand() / RAND_DIVISOR;
      sleep(rNum);

      /* aquire the full lock */
      sem_wait(&full);
      /* aquire the mutex lock */
      pthread_mutex_lock(&mutex);
      if(remove_item(&item)) {
         fprintf(stderr, "Consumer report error condition\n");
      }
      else {
         printf("consumer consumed %d\n", item);
      }
      /* release the mutex lock */
      pthread_mutex_unlock(&mutex);
      /* signal empty */
      sem_post(&empty);
   }
}

int main(int argc, const char * argv[])
{
/*
	struct fractal *myfrac = fractal_new("Test 1", 800, 800, -0.8, 0.0);
	int w,h,x,y;
	for(x = 0; x < 800; x++){
		for(y = 0; y < 800; y++){
			fractal_compute_value(myfrac,x,y);
		}
		
	}
	write_bitmap_sdl(myfrac, "Image.bmp");

    	return 0;
*/
	
	if(handle_no_arguments(argc) < 0){
		return 0;	
	}
	maxthreads = 10;
	counter = 0;
	struct fractal *fractalBuffer[maxthreads];
	int i;
	for(i = 0; i < maxthreads; i++){
		fractalBuffer[i] = malloc(sizeof(struct fractal));
	}
	sem_init(&full,0,0);
	sem_init(&empty,0,maxthreads);
	if (pthread_mutex_init(&buffer_access, NULL) != 0)
	{
		printf("\n mutex init failed\n");
		return 1;
	}

	buffer = &fractalBuffer;
	const char *filename = "inputfile1";
	pthread_t thread;
	
	if(pthread_create(&thread, NULL, readFile, filename) == -1)
		return EXIT_FAILURE;
	printf("Thread created\n");
	if(pthread_join(thread, NULL))
		return EXIT_FAILURE;
	free((*fractalBuffer));
	return 0;
}


















