#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include "libfractal/fractal.h"
#include "errorHandling.h"

#define EXIT_SIGNAL "SIGNAl_THREAD_EXIT"

struct fractal *(*buffer)[];
int counter; //current buffered data
pthread_mutex_t buffer_access;
int maxthreads;
sem_t full, empty;
const char *extension = ".bmp";

void debug_print_buffer(int a){
	int i;
	printf("DEBUG PRINT BUFFER\n");
	printf("Current counter : %d\n", counter);
	printf("Pointer to buffer : %p\n", buffer);
	printf("Pointer to last buffed : %p\n", (*buffer)[counter]);
	for(i = 0; i <counter-a; i++){
		printf("Pointer to current buffed : %p\n", (*buffer)[i]);
		printf("At counter %d the name is : %s\n", i, (*buffer)[i]->name);
	}
}
//HELP FUNCTION - TO MOVE IN OTHER FILE
char *strsep(char **stringp, const char *delim){
	char *s;
	const char *spanp;
	int c, sc;
	char *tok;

	if ((s = *stringp) == NULL)
	    return (NULL);
	for (tok = s;;) {
	    c = *s++;
	    spanp = delim;
	    do {
		    if ((sc = *spanp++) == c) {
			    if (c == 0)
				    s = NULL;
			    else
				    s[-1] = 0;
			    *stringp = s;
			    return (tok);
		    }
	    } while (sc != 0);
	}
	/* NOTREACHED */
}

struct fractal *fractal_parse(char *line){
	const char *delim = " ";
	char *name = strsep(&line, delim);
	int width = (int) atoi(strsep(&line, delim));
	int height = (int) atoi(strsep(&line, delim));
	double a = (double)atof(strsep(&line, delim));
	double b= (double) atof(strsep(&line, delim));
	struct fractal *newfractal = fractal_new(name, width, height, a, b);
	printf("P: Parsed fractal name = %s\n", fractal_get_name(newfractal));
	return newfractal;
}

int insert_fractal(struct fractal *fractal){
	/* When the buffer is not full add the item
	and increment the counter*/
	if(counter < maxthreads) {
		(*buffer)[counter] = fractal_new(fractal->name, 
			*fractal->width, *fractal->height, 
			*fractal->a, *fractal->b);
		fflush(stdout);
		fractal_free(fractal);
		counter++;
		return 0;
	}
	else { /* Error the buffer is full */
		return -1;
	}
}

int isExitSignal(struct fractal* signal){
	const char* current = fractal_get_name(signal);
	if(strcmp(current, EXIT_SIGNAL))
		return 0;
	else
		return 1;
}

int *send_signals(){
	int thread;
	for(thread = 0; thread < maxthreads; thread++){
		sem_wait(&empty);
		pthread_mutex_lock(&buffer_access);
		struct fractal *myfrac = fractal_new(EXIT_SIGNAL, 0, 0, 0, 0);
		if(insert_fractal(myfrac)) {
			fprintf(stderr, "Could not send stop signal to thread %d\n", thread);
		}
		pthread_mutex_unlock(&buffer_access);
		sem_post(&full);
	}
	return 0;
}

int *readFile(const char *filename){
	FILE *fp;
	char *line = NULL;
	size_t len = 0;
	ssize_t read;
	int iteration = 0;
	fp = fopen(filename, "r");
	if (fp == NULL)
		return -1;
	while (read != -1) {
		iteration++;
		read = getline(&line, &len, fp);
		if(read>1 && line[0]!='#'){ //ignore empty lines and comments
			sem_wait(&empty);
			pthread_mutex_lock(&buffer_access);
			struct fractal *myfrac = fractal_parse(line);
			
			if(insert_fractal(myfrac)) {
				fprintf(stderr, "Producer report error condition\n");
			}
			pthread_mutex_unlock(&buffer_access);
			sem_post(&full);
		}
		
	}
	send_signals();
	fclose(fp);
        free(line);
	pthread_exit(1);
}

int remove_fractal(struct fractal **fractal) {
   /* When the buffer is not empty remove the item
      and decrement the counter */
   if(counter > 0) {
	if(fractal_get_name((*buffer)[(counter-1)])!=NULL)
	      *fractal = fractal_new(fractal_get_name((*buffer)[(counter-1)]),
				fractal_get_width((*buffer)[(counter-1)]),
				fractal_get_height((*buffer)[(counter-1)]),
				fractal_get_a((*buffer)[(counter-1)]),
				fractal_get_b((*buffer)[(counter-1)]));
      counter--;
      return 0;
   }
   else { /* Error buffer empty */
      return -1;
   }
}

void *compute()
{
	struct fractal **fractal;
	fractal = (struct fractal**) malloc(sizeof(struct fractal*));
	while(1) {
		sem_wait(&full);
		pthread_mutex_lock(&buffer_access);
		if(remove_fractal(fractal)) {
			fprintf(stderr, "Consumer report error condition\n");
			pthread_mutex_unlock(&buffer_access);
		}
		else if(isExitSignal(*fractal)){
			fractal_free(*fractal);
			free(fractal);
			pthread_mutex_unlock(&buffer_access);
			sem_post(&empty);
			pthread_exit(0);
		}
		else {
			pthread_mutex_unlock(&buffer_access);
			int w,h,x,y;
			w=fractal_get_width(*fractal);
			h=fractal_get_height(*fractal);
			char *filename = malloc(strlen(fractal_get_name(*fractal))+strlen(extension)+1);
			filename = strcpy(filename, fractal_get_name(*fractal));
			filename = strcat(filename, extension);
			for(x = 0; x < w; x++){
				for(y = 0; y < h; y++){
					fractal_compute_value(*fractal,x,y);
				}

			}
			write_bitmap_sdl(*fractal, filename);
			printf("C:Created %s\n", filename);
			fractal_free(*fractal);
			free(filename);
		}
		/* signal empty */
		sem_post(&empty);
		
	}
	free(fractal);
	pthread_exit(0);
}

int initialize()
{
	maxthreads = 10;
	counter = 0;

	//struct fractal *fbuffer = malloc(maxthreads * sizeof(struct fractal));
	//buffer = &fbuffer;	
	buffer = malloc(maxthreads * sizeof(struct fractal));
	
	sem_init(&full, 0, 0);
	sem_init(&empty,0, maxthreads);

	if (pthread_mutex_init(&buffer_access, NULL) != 0)
	{
		printf("\n mutex init failed\n");
		return 1;
	}
	return 0;
}

int launch_threads()
{
	const char * filename = "inputfile1";
	pthread_t thread;
	//producer
	if(pthread_create(&thread, NULL, readFile, filename) == -1)
		return EXIT_FAILURE;

	//consumer
	int i;
	pthread_t thready[maxthreads];
	for(i = 0; i < maxthreads; i++) {
		pthread_create(&thready[i],NULL,compute,NULL);
	}

	if(pthread_join(thread, NULL))
		return EXIT_FAILURE;
	for(i = 0; i < maxthreads; i++) {
		if(pthread_join(thready[i], NULL))
			return EXIT_FAILURE;
	}
	free(buffer);
	return 0;
}

int main(int argc, const char * argv[])
{
	if(handle_no_arguments(argc) < 0){
		return 0;	
	}
	if(initialize())
		return NULL;
	launch_threads();
	printf("Execution finished\n");
	return 0;
}
