#ifndef _HANDLEARGUMENT_H
#define _HANDLEARGUMENT_H
struct arguments
{
	int needInput; //1=read stdin / 0=do not
	int allImages; //1=print all images / 0=do not
	int maxThreads; //maxthreads argument (10 by default)
	int inputCount; //input file count
	char** inputFiles; //input files contained in this array
	char* outputFile; 
	char* currentDirectory;
};

/*
 * handle_no_arguments: retourne la largeur de l'image de la fractale
 *
 * @argc : argument count
 * @return: 0 if there are enough arguments to process, -1 otherwise
 */
int handle_no_arguments(int argc);

/*
 * parse_arguments: returns an argument structure
 *
 * The structure sent contains every data needed during the process
 *
 * @f: fractale
 * @return: largeur
 */
struct arguments *parse_arguments(int argc, const char* argv[]);

int free_arguments(struct arguments *args);
#endif
